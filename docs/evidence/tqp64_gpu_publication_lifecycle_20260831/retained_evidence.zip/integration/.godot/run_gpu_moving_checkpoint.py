import json
import pathlib
import subprocess
import sys
import time

import psutil

project = pathlib.Path(__file__).resolve().parents[1]
output = project / '.godot/world_transvoxel_captures' / sys.argv[1]
output.mkdir(exist_ok=False)
psutil.Process().cpu_affinity([0, 1, 2])
command = [
    r'C:\Program Files (x86)\Steam\steamapps\common\Godot Engine\godot.windows.opt.tools.64.exe',
    '--path', str(project), '--rendering-driver', 'vulkan', '--audio-driver', 'Dummy',
    '--', '--p2-profile', 'g23_four_biomes_lakes_mountains_roads_2k_256_on_demand',
    '--human-material-mode', 'production_texture_array', '--human-windowed',
    '--procedural-generation-workers', '2', '--gpu-resident-render-candidate',
    '--human-visual-capture', str(output / 'moving.png'),
    '--human-visual-capture-mode', 'streaming_fly_gap_gate',
    '--human-visual-capture-wait-frames', '180',
]
started = time.perf_counter()
with (output / 'stdout.log').open('w') as stdout, (output / 'stderr.log').open('w') as stderr:
    try:
        result = subprocess.run(command, stdout=stdout, stderr=stderr, timeout=180)
        code = result.returncode
        status = 'PROCESS_EXITED'
    except subprocess.TimeoutExpired:
        code = 124
        status = 'INCOMPLETE_RUNNER_TIMEOUT'
report = dict(status=status, returncode=code, command=command, affinity=[0, 1, 2],
              elapsed_seconds=time.perf_counter() - started, runner_timeout_seconds=180)
(output / 'execution.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
raise SystemExit(code)
